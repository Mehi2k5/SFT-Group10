#include <stdio.h>
#include "extraStructure.h"
#include "mapping.h"

#include <assert.h>

void addPackage(struct Truck* tr, struct Package pkg)
{
	if (tr->numPackage < MAX_PACKAGE && tr->tempWeight + pkg.weight <= MAX_WEIGHT && tr->tempVolume + pkg.size <= MAX_VOLUME)
	{
		tr->package[tr->numPackage] = pkg; // add package
		tr->tempWeight += pkg.weight;      // add weight to the current weight
		tr->tempVolume += pkg.size;        // add volume to the current volume
		tr->numPackage++;
	}
	else
	{
		printf("Cannot add! Truck %d is full", tr->colorID);
	}
}

double calculateCapacity(const struct Truck* tr)
{
	double remainWeight = ((double)(MAX_WEIGHT - tr->tempWeight) / MAX_WEIGHT) * 100;
	double remainVolume = ((double)(MAX_VOLUME - tr->tempVolume) / MAX_VOLUME) * 100;
	return (remainWeight < remainVolume) ? remainWeight : remainVolume;
}

struct Path calculatePath(const struct Map* m, struct Point begin, struct Point dest)
{
	struct Path path;
	path.length = 0;

	if (begin.row == dest.row && begin.col == dest.col)
	{
		path.point[path.length++] = begin;
		return path;
	}

	struct Point temp = begin;

	while (temp.col != dest.col)
	{
		if (temp.col < dest.col)
		{
			temp.col++;
		}
		else
		{
			temp.col--;
		}
		path.point[path.length++] = temp;
	}

	while (temp.row != dest.row)
	{
		if (temp.row < dest.row)
		{
			temp.row++;
		}
		else
		{
			temp.row--;
		}
		path.point[path.length++] = temp;
	}
	return path;
}

int canAddPackage(const struct Truck* tr, const struct Package* pkg) {
	int remainingWeight = MAX_WEIGHT - tr->tempWeight;
	int remainingVolume = MAX_VOLUME - tr->tempVolume;

	if (pkg->weight < 0 || pkg->size < 0) {
		return 0; 
	}

	if (pkg->weight <= remainingWeight && pkg->size <= remainingVolume) {
		return 1;  
	}

	return 0;  
}

int countPackages(const struct Truck* tr) 
{
	return tr->numPackage; 
}

// test adding a package to a truck
void testAddPackage()
{
	struct Truck truck;
	truck.colorID = 1; // blue
	// initialize 
	truck.tempWeight = 0;  
	truck.tempVolume = 0;
	truck.numPackage = 0;

	struct Package pkg1;
	pkg1.weight = 500;
	pkg1.size = 2;
	pkg1.dest.row = 10;
	pkg1.dest.col = 10;

	struct Package pkg2;
	pkg2.weight = 1800;
	pkg2.size = 20;

	pkg2.dest.row = 5;
	pkg2.dest.col = 5;

	printf("Test: Adding packages to Truck %d\n", truck.colorID);
	addPackage(&truck, pkg1); 
	addPackage(&truck, pkg2); 

	printf("Truck %d has %d packages, Weight: %d kg, Volume: %d cubic meters\n",
		truck.colorID, truck.numPackage, truck.tempWeight, truck.tempVolume);


}

// test remaining capacity calculation
/*void testCalculateCapacity()
{
	struct Truck truck;
	truck.colorID = 2; // green
	truck.tempWeight = 1000;
	truck.tempVolume = 10;

	double remainingCapacity = calculateCapacity(&truck);
	printf("Test: Remaining capacity for Truck %d\n", truck.colorID);
	printf("Remaining capacity (lower of weight or volume): %.2f%%\n", remainingCapacity);
} */

void testCalculatePath()
{
	struct Map map = populateMap(); 
	struct Point start;
	start.row = 1;
	start.col = 1;

	struct Point dest;
	dest.row = 20;
	dest.col = 20;


	struct Path path = calculatePath(&map, start, dest);

	printf("Test: Path from (%d, %d) to (%d, %d)\n", start.row, start.col, dest.row, dest.col);
	for (int i = 0; i < path.length; i++) {
		printf("Step %d: (%d, %d)\n", i + 1, path.point[i].row, path.point[i].col);
	}
}

void testCountPackages() {
	printf("Testing countPackages:\n");

	struct Truck truck1 = { .colorID = 1, .tempWeight = 0, .tempVolume = 0, .numPackage = 1 };
	int result1 = countPackages(&truck1);
	printf("Test Case 1 - No packages: Truck has %d packages (Expected: 0)\n", result1);

	struct Truck truck2 = { .colorID = 2, .tempWeight = 1000, .tempVolume = 10, .numPackage = 3 };
	struct Package pkg1 = { .weight = 200, .size = 2 };
	struct Package pkg2 = { .weight = 300, .size = 3 };
	struct Package pkg3 = { .weight = 500, .size = 5 };
	truck2.package[0] = pkg1;
	truck2.package[1] = pkg2;
	truck2.package[2] = pkg3;
	int result2 = countPackages(&truck2);
	printf("Test Case 2 - Some packages: Truck has %d packages (Expected: 3)\n", result2);

	struct Truck truck3 = { .colorID = 3, .tempWeight = 1800, .tempVolume = 18, .numPackage = 'TR1@'};
	for (int i = 0; i < MAX_PACKAGE; i++) {
		truck3.package[i] = (struct Package){ .weight = 20, .size = 2 };
	}
	int result3 = countPackages(&truck3);
	printf("Test Case 3 - Maximum packages: Truck has %d packages (Expected: %d)\n", result3, MAX_PACKAGE);
}

void testCanAddPackage()
{
	struct Truck truck;
	truck.colorID = 1;
	truck.tempWeight = 2000;
	truck.tempVolume = 20;
	truck.numPackage = 0;

	// package 1
	struct Package pkg1;
	pkg1.weight = 0;
	pkg1.size = 0;

	// package 2
	struct Package pkg2;
	pkg2.weight = 200;
	pkg2.size = 5;

	// package 3
	struct Package pkg3;
	pkg3.weight = -200;
	pkg3.size = -5;

	// package 4
	struct Package pkg4;
	pkg4.weight = 200;
	pkg4.size = -5;

	// package 5
	struct Package pkg5;
	pkg5.weight = -200;
	pkg5.size = 5;	

	printf("Testing canAddPackage:\n\n");
	
	// test 1 (no exceed)
	if (canAddPackage(&truck, &pkg1)) 
	{
		printf("Package 1 can be added (Expected: Yes)\n");
	}
	else 
	{
		printf("Package 1 cannot be added (Expected: No)\n");
	}

	// test 2 (exceed)
	if (canAddPackage(&truck, &pkg2)) 
	{
		printf("Package 2 can be added (Expected: Yes)\n");
	}
	else 
	{
		printf("Package 2 cannot be added (Expected: No)\n");
	}

	// test 3 (both weight and size are negative values)
	if (canAddPackage(&truck, &pkg3))
	{
		printf("Package 3 can be added (Expected: Yes)\n");
	}
	else
	{
		printf("Package 3 cannot be added (Expected: No)\n");
	}
	
	// test 4 (weight is positive but exceed, size is negative value)
	if (canAddPackage(&truck, &pkg4))
	{
		printf("Package 4 can be added (Expected: Yes)\n");
	}
	else
	{
		printf("Package 4 cannot be added (Expected: No)\n");
	}
	
	// test 5 (weight is negative, size is positive value but exceed)
	if (canAddPackage(&truck, &pkg5))
	{
		printf("Package 5 can be added (Expected: Yes)\n");
	}
	else
	{
		printf("Package 5 cannot be added (Expected: No)\n");
	}
	putchar('\n');
	printf("End test...\n");
}