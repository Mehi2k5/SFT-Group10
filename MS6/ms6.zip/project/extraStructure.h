#ifndef EXTRA_STRUCTURE_H
#define EXTRA_STRUCTURE_H

#include "mapping.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_PACKAGE 100 // maximum number of packages that the truck can deliver
#define MAX_WEIGHT 2000 // maximum total weight in kg that the truck can deliver
#define MAX_VOLUME 20   // maximum total volume in cubic meters that the truck can deliver

    // Struct Definitions
    struct Package // Represents a package
    {
        int weight;
        int size;
        struct Point dest;
    };

    struct Truck
    {
        int colorID;                // (blue-1, green-2, yellow-3)
        int tempWeight;             // Current weight of the truck load
        int tempVolume;             // Current volume of the truck load
        int numPackage;             // Number of packages on the truck
        struct Route route;         // Route
        struct Package package[MAX_PACKAGE]; // List of packages on the truck
    };

    struct Path // Represents a shortest path
    {
        struct Point point[MAX_ROUTE]; // Points in path
        int length;                    // Length of path
    };

    // Function Declarations
    void addPackage(struct Truck* tr, struct Package pkg);
    double calculateCapacity(const struct Truck* tr);
    struct Path calculatePath(const struct Map* m, struct Point begin, struct Point dest);
    int canAddPackage(const struct Truck* tr, const struct Package* pkg);
    int countPackages(const struct Truck* tr);

    // Test Functions (optional for internal testing purposes)
    void testAddPackage();
    void testCalculatePath();
    void testCanAddPackage();
    void testCountPackages();

#ifdef __cplusplus
}
#endif

#endif // !EXTRA_STRUCTURE_H
